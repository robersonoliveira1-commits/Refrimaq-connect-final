import fs from 'fs';
const path = './src/components/WorkshopOrderView.tsx';
let content = fs.readFileSync(path, 'utf8');

const target = `      const existingIds = new Set((existingParts ?? []).map((p: { id: string }) => p.id));
      for (const part of parts) {`;

const replacement = `      const existingIds = new Set((existingParts ?? []).map((p: { id: string }) => p.id));
      const currentIds = new Set(parts.map(p => p.id).filter(Boolean));
      for (const id of existingIds) {
        if (!currentIds.has(id)) {
          await supabase.from('service_order_parts').delete().eq('id', id);
        }
      }
      for (const part of parts) {`;

if (content.includes(target)) {
  content = content.replace(target, replacement);
  fs.writeFileSync(path, content, 'utf8');
  console.log("Patched WorkshopOrderView successfully!");
} else {
  console.log("Target not found in WorkshopOrderView.");
}
