import { useState, useEffect } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Customer, Product } from '../lib/types';
import { geocodeAddress } from '../lib/geocode';

interface AddCustomerModalProps {
  customer?: Customer | null;
  onClose: () => void;
  onSuccess: () => void;
}

interface ProductEntry {
  product_name: string;
  purchase_date: string;
  invoice_number: string;
  warranty_start: string;
  warranty_end: string;
  notes: string;
}

const BLANK_PRODUCT: ProductEntry = {
  product_name: '',
  purchase_date: '',
  invoice_number: '',
  warranty_start: '',
  warranty_end: '',
  notes: '',
};

export default function AddCustomerModal({ customer, onClose, onSuccess }: AddCustomerModalProps) {
  const [form, setForm] = useState({
    name: customer?.name ?? '',
    phone: customer?.phone ?? '',
    whatsapp: customer?.whatsapp ?? '',
    email: customer?.email ?? '',
    address: customer?.address ?? '',
    city: customer?.city ?? '',
    state: customer?.state ?? '',
    zip_code: customer?.zip_code ?? '',
    document: customer?.document ?? '',
    notes: customer?.notes ?? '',
  });
  const [productEntries, setProductEntries] = useState<ProductEntry[]>([]);
  const [catalogProducts, setCatalogProducts] = useState<Product[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    supabase.from('products').select('*').eq('active', true).order('name').then(({ data }) => {
      if (data) setCatalogProducts(data);
    });
  }, []);

  function set(field: string, value: string) {
    setForm(prev => ({ ...prev, [field]: value }));
  }

  function addProduct() {
    setProductEntries(prev => [...prev, { ...BLANK_PRODUCT }]);
  }

  function updateProduct(index: number, field: string, value: string) {
    setProductEntries(prev => prev.map((p, i) => i === index ? { ...p, [field]: value } : p));
  }

  function removeProduct(index: number) {
    setProductEntries(prev => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) { setError('O nome é obrigatório.'); return; }
    setSaving(true);
    setError('');

    const payload: Record<string, unknown> = {
      name: form.name.trim(),
      phone: form.phone.trim(),
      whatsapp: form.whatsapp.trim(),
      email: form.email.trim(),
      address: form.address.trim(),
      city: form.city.trim(),
      state: form.state.trim(),
      zip_code: form.zip_code.trim(),
      document: form.document.trim(),
      notes: form.notes.trim(),
    };

    // geocode address if city or address provided
    if (form.address.trim() || form.city.trim()) {
      const coords = await geocodeAddress(form.address.trim(), form.city.trim(), form.state.trim());
      if (coords) {
        payload.latitude = coords.lat;
        payload.longitude = coords.lng;
      }
    }

    let customerId = customer?.id;

    if (customer) {
      const { error: err } = await supabase.from('customers').update(payload).eq('id', customer.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { data, error: err } = await supabase.from('customers').insert(payload).select('id').single();
      if (err || !data) { setError(err?.message ?? 'Erro ao salvar'); setSaving(false); return; }
      customerId = data.id;
    }

    // save new products
    const validProducts = productEntries.filter(p => p.product_name.trim());
    if (validProducts.length > 0 && customerId) {
      const rows = validProducts.map(p => ({
        customer_id: customerId,
        product_name: p.product_name.trim(),
        purchase_date: p.purchase_date || null,
        invoice_number: p.invoice_number.trim(),
        warranty_start: p.warranty_start || null,
        warranty_end: p.warranty_end || null,
        notes: p.notes.trim(),
      }));
      await supabase.from('customer_products').insert(rows);
    }

    onSuccess();
    onClose();
  }

  const isEdit = !!customer;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800">{isEdit ? 'Editar Cliente' : 'Novo Cliente'}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-auto px-6 py-5 space-y-5">
          {/* basic info */}
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">Dados Básicos</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Nome / Razão Social *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => set('name', e.target.value)}
                  placeholder="Nome completo ou razão social"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Telefone</label>
                <input type="tel" value={form.phone} onChange={e => set('phone', e.target.value)}
                  placeholder="(11) 99999-9999"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">WhatsApp</label>
                <input type="tel" value={form.whatsapp} onChange={e => set('whatsapp', e.target.value)}
                  placeholder="(11) 99999-9999"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">E-mail</label>
                <input type="email" value={form.email} onChange={e => set('email', e.target.value)}
                  placeholder="email@exemplo.com"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">CPF / CNPJ</label>
                <input type="text" value={form.document} onChange={e => set('document', e.target.value)}
                  placeholder="000.000.000-00"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
            </div>
          </div>

          {/* address */}
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-3">Endereço</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-3">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Endereço</label>
                <input type="text" value={form.address} onChange={e => set('address', e.target.value)}
                  placeholder="Rua, número, bairro"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Cidade</label>
                <input type="text" value={form.city} onChange={e => set('city', e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Estado</label>
                <input type="text" value={form.state} onChange={e => set('state', e.target.value)}
                  placeholder="SP"
                  maxLength={2}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">CEP</label>
                <input type="text" value={form.zip_code} onChange={e => set('zip_code', e.target.value)}
                  placeholder="00000-000"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent" />
              </div>
            </div>
          </div>

          {/* notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Observações</label>
            <textarea
              value={form.notes}
              onChange={e => set('notes', e.target.value)}
              rows={2}
              placeholder="Informações adicionais sobre o cliente..."
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent resize-none"
            />
          </div>

          {/* products (only for new customers) */}
          {!isEdit && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">Produtos Adquiridos</p>
                <button type="button" onClick={addProduct}
                  className="flex items-center gap-1 text-xs text-amber-600 hover:text-amber-700 font-medium">
                  <Plus size={13} /> Adicionar Produto
                </button>
              </div>
              {productEntries.length === 0 && (
                <p className="text-xs text-slate-400 text-center py-3 bg-slate-50 rounded-lg">
                  Nenhum produto adicionado
                </p>
              )}
              {productEntries.map((entry, i) => (
                <div key={i} className="bg-slate-50 rounded-xl p-4 mb-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-600">Produto {i + 1}</p>
                    <button type="button" onClick={() => removeProduct(i)} className="text-red-400 hover:text-red-600">
                      <Trash2 size={13} />
                    </button>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Nome do Produto</label>
                    <input
                      list={`product-list-${i}`}
                      value={entry.product_name}
                      onChange={e => updateProduct(i, 'product_name', e.target.value)}
                      placeholder="Nome da chopeira ou acessório"
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent bg-white"
                    />
                    <datalist id={`product-list-${i}`}>
                      {catalogProducts.map(p => <option key={p.id} value={p.name} />)}
                    </datalist>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Data Compra</label>
                      <input type="date" value={entry.purchase_date}
                        onChange={e => updateProduct(i, 'purchase_date', e.target.value)}
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">N. Nota Fiscal</label>
                      <input type="text" value={entry.invoice_number}
                        onChange={e => updateProduct(i, 'invoice_number', e.target.value)}
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Início Garantia</label>
                      <input type="date" value={entry.warranty_start}
                        onChange={e => updateProduct(i, 'warranty_start', e.target.value)}
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Fim Garantia</label>
                      <input type="date" value={entry.warranty_end}
                        onChange={e => updateProduct(i, 'warranty_end', e.target.value)}
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</p>}
        </form>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-3">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
            Cancelar
          </button>
          <button onClick={handleSubmit} disabled={saving}
            className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50">
            {saving ? 'Salvando...' : isEdit ? 'Salvar Alterações' : 'Criar Cliente'}
          </button>
        </div>
      </div>
    </div>
  );
}
