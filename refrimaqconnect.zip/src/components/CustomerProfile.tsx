import { useEffect, useState } from 'react';
import {
  ArrowLeft, Phone, Mail, MapPin, FileText, Package, MessageSquare,
  Plus, Edit2, Trash2, Calendar, CheckCircle,
  PhoneCall, MessageCircle, AtSign, Navigation, MoreHorizontal, Shield
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import {
  Customer, CustomerProduct, Contact, ContactSchedule,
  getContactStatus, getStatusLabel, formatDate, formatDateTime, daysSince
} from '../lib/types';
import Header from './Header';

const CONTACT_TYPE_ICONS: Record<string, React.ReactNode> = {
  phone: <PhoneCall size={14} />,
  whatsapp: <MessageCircle size={14} />,
  email: <AtSign size={14} />,
  visit: <Navigation size={14} />,
  other: <MoreHorizontal size={14} />,
};

const CONTACT_TYPE_COLORS: Record<string, string> = {
  phone: 'bg-blue-100 text-blue-700',
  whatsapp: 'bg-emerald-100 text-emerald-700',
  email: 'bg-violet-100 text-violet-700',
  visit: 'bg-orange-100 text-orange-700',
  other: 'bg-slate-100 text-slate-600',
};

const CONTACT_TYPE_LABELS: Record<string, string> = {
  phone: 'Telefone',
  whatsapp: 'WhatsApp',
  email: 'E-mail',
  visit: 'Visita',
  other: 'Outro',
};

const STATUS_BADGE: Record<string, string> = {
  green: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  yellow: 'bg-amber-100 text-amber-700 border-amber-200',
  red: 'bg-red-100 text-red-700 border-red-200',
  gray: 'bg-slate-100 text-slate-600 border-slate-200',
};

interface CustomerProfileProps {
  customerId: string;
  onBack: () => void;
  onAddContact: (customerId: string) => void;
  onEditCustomer: (customer: Customer) => void;
  onMenuClick: () => void;
  refresh: number;
}

export default function CustomerProfile({
  customerId, onBack, onAddContact, onEditCustomer, onMenuClick, refresh
}: CustomerProfileProps) {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [products, setProducts] = useState<CustomerProduct[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [schedules, setSchedules] = useState<ContactSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'contacts' | 'products' | 'schedules'>('contacts');

  useEffect(() => {
    loadAll();
  }, [customerId, refresh]);

  async function loadAll() {
    setLoading(true);
    const [customerRes, productsRes, contactsRes, schedulesRes] = await Promise.all([
      supabase.from('customers').select('*').eq('id', customerId).maybeSingle(),
      supabase.from('customer_products').select('*').eq('customer_id', customerId).order('purchase_date', { ascending: false }),
      supabase.from('contacts').select('*').eq('customer_id', customerId).order('contacted_at', { ascending: false }),
      supabase.from('contact_schedules').select('*').eq('customer_id', customerId).eq('completed', false).order('scheduled_at'),
    ]);
    if (customerRes.data) setCustomer(customerRes.data);
    if (productsRes.data) setProducts(productsRes.data);
    if (contactsRes.data) setContacts(contactsRes.data);
    if (schedulesRes.data) setSchedules(schedulesRes.data);
    setLoading(false);
  }

  async function deleteContact(id: string) {
    
    await supabase.from('contacts').delete().eq('id', id);
    loadAll();
  }

  async function completeSchedule(id: string) {
    await supabase.from('contact_schedules').update({ completed: true }).eq('id', id);
    loadAll();
  }

  if (loading) {
    return (
      <div className="flex flex-col h-full">
        <Header title="Carregando..." onMenuClick={onMenuClick} />
        <div className="flex-1 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="flex flex-col h-full">
        <Header title="Cliente não encontrado" onMenuClick={onMenuClick} />
        <div className="flex-1 flex items-center justify-center">
          <button onClick={onBack} className="text-amber-600 hover:underline text-sm">Voltar</button>
        </div>
      </div>
    );
  }

  const status = getContactStatus(customer.last_contact_at);

  return (
    <div className="flex flex-col h-full">
      <Header
        title={customer.name}
        subtitle={`${customer.city ? customer.city + (customer.state ? `, ${customer.state}` : '') : 'Sem localização'}`}
        onMenuClick={onMenuClick}
        actions={
          <div className="flex gap-2">
            <button
              onClick={() => onEditCustomer(customer)}
              className="flex items-center gap-1.5 border border-slate-200 hover:bg-slate-50 text-slate-600 px-3 py-1.5 rounded-lg text-sm transition-colors"
            >
              <Edit2 size={14} />
              <span className="hidden sm:inline">Editar</span>
            </button>
            <button
              onClick={() => onAddContact(customerId)}
              className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
            >
              <Plus size={14} />
              <span className="hidden sm:inline">Registrar Contato</span>
            </button>
          </div>
        }
      />

      <div className="flex-1 overflow-auto p-4 sm:p-6 space-y-4">
        {/* back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 transition-colors"
        >
          <ArrowLeft size={16} />
          Voltar para a lista
        </button>

        {/* customer info card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-amber-700 font-bold text-xl">
                {customer.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-slate-800">{customer.name}</h2>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${STATUS_BADGE[status]}`}>
                  {getStatusLabel(status)} — {daysSince(customer.last_contact_at)}
                </span>
              </div>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                {customer.phone && (
                  <a href={`tel:${customer.phone}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-amber-600 transition-colors">
                    <Phone size={14} className="text-slate-400" />
                    {customer.phone}
                  </a>
                )}
                {customer.whatsapp && (
                  <a href={`https://wa.me/${(() => { const digits = customer.whatsapp.replace(/\D/g, ''); return digits.startsWith('55') ? digits : '55' + digits; })()}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 text-sm text-slate-600 hover:text-emerald-600 transition-colors">
                    <MessageCircle size={14} className="text-slate-400" />
                    {customer.whatsapp}
                  </a>
                )}
                {customer.email && (
                  <a href={`mailto:${customer.email}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-amber-600 transition-colors">
                    <Mail size={14} className="text-slate-400" />
                    {customer.email}
                  </a>
                )}
                {(customer.address || customer.city) && (
                  <span className="flex items-center gap-2 text-sm text-slate-600">
                    <MapPin size={14} className="text-slate-400" />
                    {[customer.address, customer.city, customer.state].filter(Boolean).join(', ')}
                  </span>
                )}
                {customer.document && (
                  <span className="flex items-center gap-2 text-sm text-slate-600">
                    <FileText size={14} className="text-slate-400" />
                    {customer.document}
                  </span>
                )}
              </div>
              {customer.notes && (
                <p className="mt-3 text-sm text-slate-500 bg-slate-50 rounded-lg p-3 italic">{customer.notes}</p>
              )}
            </div>
          </div>
        </div>

        {/* upcoming schedules */}
        {schedules.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
            <p className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-1.5">
              <Calendar size={14} />
              Contatos Agendados
            </p>
            <div className="space-y-2">
              {schedules.map(s => (
                <div key={s.id} className="flex items-center gap-3 bg-white rounded-lg p-3 border border-amber-100">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-700">{formatDateTime(s.scheduled_at)}</p>
                    {s.assigned_to && <p className="text-xs text-slate-500">Responsável: {s.assigned_to}</p>}
                    {s.notes && <p className="text-xs text-slate-500 mt-0.5">{s.notes}</p>}
                  </div>
                  <button
                    onClick={() => completeSchedule(s.id)}
                    className="flex items-center gap-1 text-xs text-emerald-600 hover:text-emerald-700 font-medium transition-colors"
                  >
                    <CheckCircle size={14} />
                    Concluído
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* tabs */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="flex border-b border-slate-100">
            {[
              { key: 'contacts', label: 'Histórico de Contatos', count: contacts.length },
              { key: 'products', label: 'Produtos', count: products.length },
              { key: 'schedules', label: 'Agendamentos', count: schedules.length },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.key
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {tab.label}
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  activeTab === tab.key ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* contact history */}
          {activeTab === 'contacts' && (
            <div>
              {contacts.length === 0 ? (
                <div className="p-10 text-center">
                  <MessageSquare size={36} className="text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 font-medium">Nenhum contato registrado</p>
                  <button
                    onClick={() => onAddContact(customerId)}
                    className="mt-3 text-amber-600 hover:underline text-sm"
                  >
                    Registrar primeiro contato
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {contacts.map(contact => (
                    <div key={contact.id} className="p-4 hover:bg-slate-50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${CONTACT_TYPE_COLORS[contact.contact_type] || CONTACT_TYPE_COLORS.other}`}>
                          {CONTACT_TYPE_ICONS[contact.contact_type] || CONTACT_TYPE_ICONS.other}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${CONTACT_TYPE_COLORS[contact.contact_type] || CONTACT_TYPE_COLORS.other}`}>
                              {CONTACT_TYPE_LABELS[contact.contact_type] || 'Outro'}
                            </span>
                            <span className="text-xs text-slate-400">{formatDateTime(contact.contacted_at)}</span>
                            {contact.contacted_by && (
                              <span className="text-xs text-slate-400">por {contact.contacted_by}</span>
                            )}
                          </div>
                          <p className="mt-1.5 font-medium text-slate-700 text-sm">{contact.subject}</p>
                          {contact.details && (
                            <p className="mt-1 text-sm text-slate-500 leading-relaxed">{contact.details}</p>
                          )}
                          {contact.comprovante_url && (
                            <a href={contact.comprovante_url} target="_blank" rel="noopener noreferrer"
                              className="mt-2 inline-block rounded-lg overflow-hidden border border-slate-200 hover:border-amber-400 transition-colors">
                              <img src={contact.comprovante_url} alt="Comprovante" className="w-24 h-24 object-cover" />
                            </a>
                          )}
                          {contact.next_contact_at && (
                            <div className="mt-2 flex items-center gap-1.5 text-xs text-amber-600 bg-amber-50 rounded-lg px-2.5 py-1.5 w-fit">
                              <Calendar size={11} />
                              Próximo contato: {formatDateTime(contact.next_contact_at)}
                              {contact.next_contact_notes && ` — ${contact.next_contact_notes}`}
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => setDeleteConfirm(contact.id)}
                          className="text-slate-300 hover:text-red-400 transition-colors flex-shrink-0"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* products */}
          {activeTab === 'products' && (
            <div>
              {products.length === 0 ? (
                <div className="p-10 text-center">
                  <Package size={36} className="text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 font-medium">Nenhum produto registrado</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {products.map(p => (
                    <div key={p.id} className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 bg-amber-50 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Package size={16} className="text-amber-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-slate-700">{p.product_name}</p>
                          <div className="mt-1 flex flex-wrap gap-3 text-xs text-slate-500">
                            {p.purchase_date && <span>Compra: {formatDate(p.purchase_date)}</span>}
                            {p.invoice_number && <span>NF: {p.invoice_number}</span>}
                            {p.warranty_start && p.warranty_end && (
                              <span className="flex items-center gap-1">
                                <Shield size={10} />
                                Garantia: {formatDate(p.warranty_start)} a {formatDate(p.warranty_end)}
                              </span>
                            )}
                          </div>
                          {p.notes && <p className="mt-1 text-xs text-slate-400">{p.notes}</p>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* schedules history */}
          {activeTab === 'schedules' && (
            <div>
              {schedules.length === 0 ? (
                <div className="p-10 text-center">
                  <Calendar size={36} className="text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 font-medium">Nenhum agendamento pendente</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {schedules.map(s => (
                    <div key={s.id} className="p-4 flex items-center gap-3">
                      <Calendar size={16} className="text-amber-500 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-700">{formatDateTime(s.scheduled_at)}</p>
                        {s.assigned_to && <p className="text-xs text-slate-500">Para: {s.assigned_to}</p>}
                        {s.notes && <p className="text-xs text-slate-500">{s.notes}</p>}
                      </div>
                      <button
                        onClick={() => completeSchedule(s.id)}
                        className="text-xs text-emerald-600 hover:text-emerald-700 font-medium transition-colors"
                      >
                        Concluir
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm flex flex-col items-center">
            <h3 className="text-lg font-bold text-slate-800 mb-2">Confirmar Exclusão</h3>
            <p className="text-sm text-slate-500 text-center mb-4">Excluir este registro de contato? Esta ação não pode ser desfeita.</p>
            <div className="flex gap-3 w-full">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50">Cancelar</button>
              <button onClick={() => { if (deleteConfirm) deleteContact(deleteConfirm); setDeleteConfirm(null); }} className="flex-1 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">Sim, excluir</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
