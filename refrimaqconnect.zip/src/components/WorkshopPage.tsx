import { useState, useEffect } from 'react';
import { Wrench, Plus, Search, Clock, CheckCircle2, XCircle, Loader2, AlertTriangle, ChevronRight, Smartphone } from 'lucide-react';
import { supabase } from '../lib/supabase';
import TechnicianOSView from './TechnicianOSView';

interface ServiceOrder {
  id: string;
  order_number: number;
  status: string;
  visit_type: string;
  priority: string;
  diagnosis: string;
  labor_cost: number;
  created_at: string;
  updated_at: string;
  customer_id: string;
  equip_model: string;
  equip_serial: string;
  customers?: { name: string; city: string };
  user_profiles?: { full_name: string };
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  'Triagem':               { label: 'Triagem',           color: 'bg-slate-100 text-slate-700',   icon: Clock },
  'Aguardando Orçamento':  { label: 'Orçamento',         color: 'bg-blue-100 text-blue-700',     icon: Clock },
  'Aguardando Peças':      { label: 'Aguardando Peças',  color: 'bg-amber-100 text-amber-700',   icon: AlertTriangle },
  'Em Manutenção':         { label: 'Em Manutenção',     color: 'bg-orange-100 text-orange-700', icon: Wrench },
  'Concluída':             { label: 'Concluída',         color: 'bg-green-100 text-green-700',   icon: CheckCircle2 },
  'Cancelada':             { label: 'Cancelada',         color: 'bg-red-100 text-red-700',       icon: XCircle },
};

const PRIORITY_COLOR: Record<string, string> = {
  'Baixa':   'bg-slate-100 text-slate-600',
  'Média':   'bg-blue-100 text-blue-700',
  'Alta':    'bg-orange-100 text-orange-700',
  'Urgente': 'bg-red-100 text-red-700',
};

const ALL_STATUSES = ['Triagem', 'Aguardando Orçamento', 'Aguardando Peças', 'Em Manutenção', 'Concluída', 'Cancelada'];

type View = 'orders';
type WorkshopTab = 'orders' | 'mobile';

interface Props {
  onMenuClick: () => void;
  onSelectOrder: (id: string) => void;
  onNewOrder: () => void;
  refresh: number;
}

export default function WorkshopPage({ onMenuClick, onSelectOrder, onNewOrder, refresh }: Props) {
  const [view, setView] = useState<View>('orders');
  const [workshopTab, setWorkshopTab] = useState<WorkshopTab>('orders');
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    loadOrders();
  }, [refresh]);

  async function loadOrders() {
    setLoading(true);
    const { data } = await supabase
      .from('service_orders')
      .select('*, customers(name, city), user_profiles(full_name)')
      .order('order_number', { ascending: false });
    setOrders((data as unknown as ServiceOrder[]) ?? []);
    setLoading(false);
  }

  const filtered = orders.filter(o => {
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    const q = search.toLowerCase();
    const matchSearch = !q
      || String(o.order_number).includes(q)
      || (o.customers?.name ?? '').toLowerCase().includes(q)
      || o.visit_type.toLowerCase().includes(q)
      || o.diagnosis.toLowerCase().includes(q)
      || (o.equip_serial ?? '').toLowerCase().includes(q)
      || (o.equip_model ?? '').toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  const counts = ALL_STATUSES.reduce<Record<string, number>>((acc, s) => {
    acc[s] = orders.filter(o => o.status === s).length;
    return acc;
  }, {});

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-4">
        <div className="flex items-center gap-3 mb-3">
          <button className="lg:hidden text-slate-500" onClick={onMenuClick}>
            <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-slate-800">Oficina</h1>
          </div>
          {workshopTab === 'orders' && (
            <button
              onClick={onNewOrder}
              className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              <Plus size={16} />
              <span className="hidden sm:inline">Nova OS</span>
            </button>
          )}
        </div>

        {/* Tab switcher */}
        <div className="flex gap-1 bg-slate-100 rounded-xl p-1 mb-3">
          <button
            onClick={() => setWorkshopTab('orders')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${workshopTab === 'orders' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Wrench size={13} />
            Ordens de Serviço
          </button>
          <button
            onClick={() => setWorkshopTab('mobile')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${workshopTab === 'mobile' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Smartphone size={13} />
            Acesso Mobile
          </button>
        </div>

        {/* Orders filters — only when viewing orders */}
        {workshopTab === 'orders' && (
          <>
            <div className="relative mb-3">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por número, cliente, tipo..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-400"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              <button
                onClick={() => setStatusFilter('all')}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${statusFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                Todas ({orders.length})
              </button>
              {ALL_STATUSES.map(s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${statusFilter === s ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                  {STATUS_CONFIG[s].label} ({counts[s] ?? 0})
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Mobile tab content */}
      {workshopTab === 'mobile' && (
        <div className="flex-1 min-h-0 overflow-y-auto">
          <TechnicianOSView embedded />
        </div>
      )}

      {/* Orders list content */}
      {workshopTab === 'orders' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {loading && (
            <div className="flex items-center justify-center py-16">
              <Loader2 size={28} className="text-amber-500 animate-spin" />
            </div>
          )}
            {!loading && filtered.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400">
                <Wrench size={40} className="mb-3 opacity-30" />
                <p className="font-medium">Nenhuma OS encontrada</p>
              </div>
            )}
            {!loading && filtered.map(order => {
              const sc = STATUS_CONFIG[order.status] ?? STATUS_CONFIG['Triagem'];
              const StatusIcon = sc.icon;
              return (
                <button
                  key={order.id}
                  onClick={() => onSelectOrder(order.id)}
                  className="w-full bg-white border border-slate-200 rounded-xl p-4 hover:border-amber-300 hover:shadow-sm transition-all text-left flex items-center gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="font-mono font-bold text-slate-700 text-sm">
                        #{String(order.order_number).padStart(4, '0')}
                      </span>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${sc.color}`}>
                        <StatusIcon size={11} />
                        {sc.label}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${PRIORITY_COLOR[order.priority] ?? ''}`}>
                        {order.priority}
                      </span>
                    </div>
                    <p className="font-semibold text-slate-800 truncate">{order.customers?.name ?? '—'}</p>
                    {(order.equip_model || order.equip_serial) && (
                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {order.equip_model && <span className="font-medium text-slate-600">{order.equip_model}</span>}
                        {order.equip_model && order.equip_serial && <span className="mx-1.5 text-slate-300">·</span>}
                        {order.equip_serial && <span className="font-mono">{order.equip_serial}</span>}
                      </p>
                    )}
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                      <span>{order.visit_type}</span>
                      {order.customers?.city && <span>· {order.customers.city}</span>}
                      {order.user_profiles?.full_name && <span>· {order.user_profiles.full_name}</span>}
                    </div>
                    {order.diagnosis && (
                      <p className="text-xs text-slate-400 mt-1 truncate">{order.diagnosis}</p>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <ChevronRight size={16} className="text-slate-300" />
                    <span className="text-xs text-slate-400">
                      {new Date(order.updated_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
      )}
    </div>
  );
}
