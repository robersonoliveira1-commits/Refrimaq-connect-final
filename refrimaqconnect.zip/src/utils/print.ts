export async function printHtml(html: string, filename = 'documento.pdf') {
  console.log("Generating PDF:", filename);
  let jsPDF, html2canvas;
  try {
    const jspdfModule = await import('jspdf');
    jsPDF = jspdfModule.jsPDF;
    const h2cModule = await import('html2canvas');
    html2canvas = h2cModule.default;
  } catch (e) {
    console.error("Erro ao carregar bibliotecas de PDF", e);
    alert('Erro ao carregar bibliotecas de PDF');
    return;
  }

  const printContainer = document.createElement('div');
  
  const styleMatch = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const styleContent = styleMatch ? styleMatch[1] : '';
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  const bodyContent = bodyMatch ? bodyMatch[1] : html;

  printContainer.innerHTML = `<style>${styleContent}</style><div id="pdf-wrapper" style="width: 760px; background: white; padding: 20px; color: black;">${bodyContent}</div>`;
  
  printContainer.style.position = 'absolute';
  printContainer.style.left = '-9999px';
  printContainer.style.top = '0';
  printContainer.style.zIndex = '-9999';
  document.body.appendChild(printContainer);

  try {
    const images = printContainer.querySelectorAll('img');
    const promises = Array.from(images).map(img => {
      if (img.complete) return Promise.resolve();
      return new Promise((resolve) => {
        img.onload = resolve;
        img.onerror = resolve;
      });
    });
    
    await new Promise(r => setTimeout(r, 500));
    await Promise.all(promises);

    const wrapper = printContainer.querySelector('#pdf-wrapper') as HTMLElement;
    if (!wrapper) throw new Error('Wrapper not found');

    const canvas = await html2canvas(wrapper, { 
      scale: 2, 
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(filename);
  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    alert('Não foi possível gerar o PDF. Verifique se as imagens permitem acesso (CORS).');
  } finally {
    if (document.body.contains(printContainer)) {
      document.body.removeChild(printContainer);
    }
  }
}
